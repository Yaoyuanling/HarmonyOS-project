package com.harmony.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.harmony.entity.User;

@Repository
public class UserDaoImpl {
	@Resource
	private JdbcTemplate jdbcTemplate;
	
	public int saveUser(User user) {
		int count = 0;
		if(selectUser(user)==null) {
			
		}else {
			String sql = "insert into user(name,maxScore) values(?,?)";
			count = this.jdbcTemplate.update(sql,user.getName(),user.getMaxScore());
		}
		
		return count;
	}
	public User selectUser(User user) {
		String sql = "select * from user where name = ?";
		List<User> list = this.jdbcTemplate.query(sql,new Object[] {user.getName()},new RowMapper<User>() {
			@Override
			public User mapRow(ResultSet rs, int arg1) throws SQLException {
				User user = new User();
				user.setId(rs.getInt(1));
				user.setName(rs.getString(2));
				user.setMaxScore(rs.getInt(3));
				System.out.println(user.toString());
				return user;
			}
		});
		if(list.size()!=0) {
			return list.get(0);
		}else {
			return new User();
		}
	}
	/**
	 * 查询前三名的成绩
	 * @return
	 */
	public List<User> listAllUser(){
		String sql = "select * from user order by maxScore desc limit 0,3";
		List<User> list = this.jdbcTemplate.query(sql,new RowMapper<User>() {
			@Override
			public User mapRow(ResultSet rs, int arg1) throws SQLException {
				User user = new User();
				user.setId(rs.getInt(1));
				user.setName(rs.getString(2));
				user.setMaxScore(rs.getInt(3));
				System.out.println(user.toString());
				return user;
			}
		});
		return list;
	}
	
	public int updateScore(User user) {
		String sql = "update user set score = ? where name = ?";
		int count = this.jdbcTemplate.update(sql,user.getMaxScore(),user.getName());
		return count;
	}
	
}
