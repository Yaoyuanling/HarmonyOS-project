package com.harmony.service;

import java.util.List;

import javax.annotation.Resource;
import org.springframework.transaction.annotation.Transactional;

import org.springframework.stereotype.Service;

import com.harmony.dao.UserDaoImpl;
import com.harmony.entity.User;

@Service
public class UserServiceImpl {
	
	@Resource
	private UserDaoImpl userDaoImpl;
	
	public boolean saveUser(User user) {
		int count = this.userDaoImpl.saveUser(user);
		if(count!=0) {
			return true;
		}else {
			return false;
		}
		
	}
	
	public List<User> listUser(){
		return this.userDaoImpl.listAllUser();
	}
	
	public boolean updateScore(User user) {
		int count = this.userDaoImpl.updateScore(user);
		if(count!=0) {
			return true;
		}else {
			return false;
		}
		
	}
}
