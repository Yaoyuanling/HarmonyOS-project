package com.harmony.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.harmony.entity.User;
import com.harmony.service.UserServiceImpl;

@Controller
@RequestMapping("/user")
public class UserController {
	@Resource
	private UserServiceImpl userServiceImpl;
	
	@RequestMapping(value = "/list",produces="text/html;charset=UTF-8")
	@ResponseBody
	public String list(HttpServletResponse response) {
		System.out.println("hello");
		response.setCharacterEncoding("UTF-8");
		User user = new User();
		user.setId(1);user.setName("苗龙龙");user.setMaxScore(100);
		Gson gson = new Gson();
		String json = gson.toJson(user);
		
		return json;
	}
	/**
	 * 添加用户
	 * @param json
	 * @return
	 */
	@RequestMapping(value = "/save",produces="text/html;charset=UTF-8")
	@ResponseBody  //,@RequestParam("str")String json
	public String saveUser(@RequestBody String json) {
		Gson gson = new Gson();
		User user = gson.fromJson(json,User.class);
		if(userServiceImpl.saveUser(user)) {
			return "ok";
		}else {
			return "false";
		}
		
	}
	/**
	 * 列出前三名用户
	 * @return
	 */
	@RequestMapping(value = "/all",produces="text/html;charset=UTF-8")
	@ResponseBody
	public String listAllUser() {
		List<User> list = this.userServiceImpl.listUser();
		Gson gson = new Gson();
		String json = gson.toJson(list);
		return json;
	}
	
	/**
	 * 更新用户成绩
	 * @return
	 */
	@RequestMapping(value = "/update",produces="text/html;charset=UTF-8")
	@ResponseBody
	public String updateScore(@RequestParam("str")String json) {
		Gson gson = new Gson();
		User user = gson.fromJson(json,User.class);
		if(this.userServiceImpl.updateScore(user)) {
			return "ok";
		}else {
			return "false";
		}
	}
}
