package com.harmony.entity;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.harmony.service.UserServiceImpl;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
//		UserServiceImpl userServiceImpl = (UserServiceImpl) ctx.getBean("UserServiceImpl");
		User user = new User();
//		user.setMaxScore(100);user.setName("miao");
//		userServiceImpl.saveUser(user);
		System.out.println(null==user.getId());
	}

}
