package com.example.snake;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}
